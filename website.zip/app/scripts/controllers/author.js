'use strict';

/**
 * @ngdoc function
 * @name websiteApp.controller:AuthorCtrl
 * @description
 * # AuthorCtrl
 * Controller of the websiteApp
 */
angular.module('websiteApp')
  .controller('AuthorCtrl', function ($scope) {
  });
